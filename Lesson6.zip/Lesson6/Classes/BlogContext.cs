﻿using System.Data.Entity;

namespace Lesson6
{
    internal class BlogContext:DbContext
    {
        public BlogContext() : base("Fpoly")
        {

        }
        public DbSet<Blog> Blogs { get; set;}
        
        public DbSet<Post> Posts { get; set;}

    }
}
