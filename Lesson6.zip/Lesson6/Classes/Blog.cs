﻿using System.Collections.Generic;

namespace Lesson6
{
    internal class Blog
    {
        public int BlogId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public List<Post> Posts { get; set; }
    }
}
