﻿using System;
using System.Data.Entity;
using System.Windows.Forms;
using Lesson6;
namespace Lesson6
{
    public partial class Lesson6 : Form
    {
        public Lesson6()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Create Db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCreateDb_Click(object sender, EventArgs e)
        {
            using (var database = new BlogContext())
            {
                database.Database.CreateIfNotExists();
            }
        }

        private void btnCreateBlog_Click(object sender, EventArgs e)
        {

        }
    }
}
